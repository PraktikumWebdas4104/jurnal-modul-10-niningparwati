SOAL JURNALLLLLL Modul 10
gunakan konsep Object Oriented Programming dengan MVC !!!

1. Buatlah sebuah database dengan nama tabel mahasiswa.
2. Di dalam tabel mahasiswa terdapat nim, nama, angkatan, fakultas, program.
3. Lengkapilah kode pada file yang telah disediakan

Lengkapilah seluruh kode dari contoh CRUD sederhana untuk mengelola data mahasiswa. Method insert, update, select dan delete

Ingat ingat modul 9 kemarin yaa :)